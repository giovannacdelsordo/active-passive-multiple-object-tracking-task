from MathUtils import cart2pol, pol2cart, getRandomAngle
from math import hypot, atan2


class Circle:
    def __init__(self, visual, xVelocity, yVelocity):
        self.visual = visual
        self.xVelocity = xVelocity
        self.yVelocity = yVelocity

    def bounceOffBorder(self, borders):
        xMin, xMax, yMin, yMax = borders
        x, y = self.visual.pos
        radius = self.visual.radius
        if x + radius >= xMax and self.xVelocity > 0:
            self.xVelocity = -self.xVelocity
        if x - radius <= xMin and self.xVelocity < 0:
            self.xVelocity = -self.xVelocity
        if y + radius >= yMax and self.yVelocity > 0:
            self.yVelocity = -self.yVelocity
        if y - radius <= yMin and self.yVelocity < 0:
            self.yVelocity = -self.yVelocity

    def bounceOffOther(self, other, minDistance):
        x, y = self.visual.pos
        xOther, yOther = other.visual.pos
        # Distance check
        xDiff = x - xOther
        yDiff = y - yOther
        distance = hypot(xDiff, yDiff)
        if distance > minDistance:
            return
        # Collision check
        # Bug fix: the original code compared self.yVelocity to other.xVelocity
        # on one branch of the y check. Both branches now compare like axes.
        xVelocityCheck = (
            (x < xOther and self.xVelocity > other.xVelocity)
            or (xOther < x and other.xVelocity > self.xVelocity)
        )
        yVelocityCheck = (
            (y < yOther and self.yVelocity > other.yVelocity)
            or (yOther < y and other.yVelocity > self.yVelocity)
        )
        if not (xVelocityCheck or yVelocityCheck):
            return
        angleOfCollision = atan2(yDiff, xDiff)
        # Coordinate transformation
        angle, speed = cart2pol(self.xVelocity, self.yVelocity)
        angleOther, speedOther = cart2pol(other.xVelocity, other.yVelocity)
        angle = angle - angleOfCollision
        angleOther = angleOther - angleOfCollision
        # Elastic bounce (https://en.wikipedia.org/wiki/Elastic_collision)
        self.xVelocity, self.yVelocity = pol2cart(angle, speed)
        other.xVelocity, other.yVelocity = pol2cart(angleOther, speedOther)
        self.xVelocity, other.xVelocity = other.xVelocity, self.xVelocity
        self.yVelocity, other.yVelocity = other.yVelocity, self.yVelocity
        # Inverse coordinate transformation
        angle, speed = cart2pol(self.xVelocity, self.yVelocity)
        angleOther, speedOther = cart2pol(other.xVelocity, other.yVelocity)
        angle = angle + angleOfCollision
        angleOther = angleOther + angleOfCollision
        # Velocity update
        self.xVelocity, self.yVelocity = pol2cart(angle, speed)
        other.xVelocity, other.yVelocity = pol2cart(angleOther, speedOther)

    def setRandomAngle(self):
        _, speed = cart2pol(self.xVelocity, self.yVelocity)
        angle = getRandomAngle()
        self.xVelocity, self.yVelocity = pol2cart(angle, speed)

    def move(self, time):
        x, y = self.visual.pos
        x = x + self.xVelocity * time
        y = y + self.yVelocity * time
        self.visual.pos = (x, y)

    def setColor(self, color, lineWidth):
        self.visual.lineWidth = lineWidth
        self.visual.lineColor = color
        self.visual.fillColor = color

    def setLine(self, color, lineWidth):
        self.visual.lineWidth = lineWidth
        self.visual.lineColor = color