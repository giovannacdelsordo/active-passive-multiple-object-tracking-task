from math import atan2, hypot, cos, sin, pi
from random import uniform


def cart2pol(x, y):
    return (atan2(y, x), hypot(x, y))


def pol2cart(angle, distance):
    return (cos(angle) * distance, sin(angle) * distance)


def getRandomAngle():
    return uniform(0, 2 * pi)