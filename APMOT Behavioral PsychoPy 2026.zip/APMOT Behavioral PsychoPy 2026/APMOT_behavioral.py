#!/usr/bin/env python
# AP-MOT behavioral-only experiment (no eye-tracking), PsychoPy 2026.x
#
# Companion engine module: libsmot_behavioral.py

# Optionally lock the engine version for reproducibility. Comment out
# if running on a Python interpreter newer than what the locked version
# supports. Uses the "useVersion" mechanism shipped with PsychoPy.
# from psychopy import useVersion
# useVersion('2026.1.3')

from psychopy import core, visual, event, gui
from random import uniform, shuffle
import csv
import libsmot as libsmot


# -----------------------------
# Auxiliary functions
# -----------------------------
def showTextAndWaitSpace(text):
    textBox.text = text
    textBox.autoDraw = True
    win.flip()
    textBox.autoDraw = False
    event.waitKeys(keyList=["space"])


def showTextAndImageAndWaitSpace(text, imageStim, textPos=(0, 250)):
    """Show instruction text in the upper portion of the screen with an
    illustrative image at the bottom, on the same display.

    The text position is temporarily shifted upward, then restored on exit.
    """
    originalPos = textBox.pos
    textBox.pos = textPos
    textBox.text = text
    textBox.autoDraw = True
    imageStim.autoDraw = True
    win.flip()
    textBox.autoDraw = False
    imageStim.autoDraw = False
    textBox.pos = originalPos
    event.waitKeys(keyList=["space"])


def fixationCrossProcedure(cross):
    cross.autoDraw = True
    win.flip()
    cross.autoDraw = False


# -----------------------------
# Participant information
# -----------------------------
def collectParticipantInfo():
    participant_number, age, gender = None, None, None
    while not (participant_number and age and gender):
        dlg = gui.Dlg(title="Participant information")
        dlg.addField(key="participant_number", label="Participant number")
        dlg.addField(key="age", label="Age")
        dlg.addField(key="gender", label="Gender",
                     choices=["Male", "Female", "Other"])
        data = dlg.show()
        if not dlg.OK:
            core.quit()
        participant_number = (data.get("participant_number") or "").strip()
        age = (data.get("age") or "").strip()
        gender = data.get("gender")
    return participant_number, age, gender


participant_number, age, gender = collectParticipantInfo()

# File name (B for behavioral, to distinguish from eye-tracking sessions)
file_name = "A_{}".format(participant_number)

# -----------------------------
# Window
# -----------------------------
win = visual.Window(
    (2560, 1440),
    units="pix",
    fullscr=False,
    allowGUI=False,
    colorSpace='rgb255',
    color=[128, 128, 128],
)
w = win.size[0] / 2
h = win.size[1] / 2
# Cursor visibility is managed per-phase inside libsmot_behavioral.runCondition

# Create AP-MOT engine
apmot = libsmot.APMOT(win)
apmot.initCircles()

# Text boxes
textBox = visual.TextBox2(win, text="", alignment="center",
                          autoDraw=False, letterHeight=35)
crossTextBox = visual.TextBox2(win, text="+", pos=(0, 0), color="white",
                               alignment="center", autoDraw=False)

# Illustrative diagrams for the AMOT and PMOT instructions, anchored in the
# lower half of the screen so the verbal instructions can sit above them on
# the same display.
amotImage = visual.ImageStim(win, image="amot.png", pos=(0, -350),
                             size=(1800, 400))
pmotImage = visual.ImageStim(win, image="pmot.png", pos=(0, -350),
                             size=(1800, 400))

# Settings
# Pre-trial fixation period (seconds). Kept brief in the behavioral version;
# increase if a longer baseline period is desired.
fixationCrossTime = 1.0

# -----------------------------
# CSV file
# -----------------------------
csv_filename = "{}.csv".format(file_name)
csvFile = open(csv_filename, "w", newline="")
csvWriter = csv.writer(csvFile)
csvWriter.writerow([
    "age", "gender", "task", "trialNumber", "difficulty",
    "reactionTime", "correctAnswers", "wrongAnswers",
    "conditionSuccess", "amot_duration", "pmot_duration",
])
csvFile.flush()

# -----------------------------
# Trial structure
# -----------------------------
nRedCirclesPerConditionPractice = [2, 4]
# Difficulty order is shuffled independently per block (see inside the loop).
steadyPerCondition = [True, False]
shuffle(steadyPerCondition)

# -----------------------------
# Instructions
# -----------------------------
showTextAndWaitSpace(
    "Welcome to this experiment.\n\n\n"
    "Press the space bar to continue."
)

showTextAndWaitSpace(
    "The experiment is divided into two sections. Please pay attention "
    "to the different instructions and read them carefully. The difference "
    "between the two tasks is very subtle!\n\n"
    "Press the space bar to continue."
)

for isSteady in steadyPerCondition:

    # Independent difficulty order for each block
    nRedCirclesPerCondition = [2, 4] * 20
    shuffle(nRedCirclesPerCondition)

    if not isSteady:
        showTextAndImageAndWaitSpace(
            "For this part of the experiment, you will be tracking moving balls around the screen.\n"
            "You will first see 10 blue balls.\n"
            "Then, some of the blue balls will turn red for one second (either 2 or 4 balls).\n"
            "You will have to focus on these red balls and remember them, because you will have to track them.\n"
            "After a few seconds, the red balls will turn blue again and will start moving.\n"
            "Your job is to keep track of ALL the balls that previously turned red, as they move around the screen.\n"
            "When the balls stop moving, you can use the mouse to click on the balls that you tracked (the ones that turned red earlier).\n"
            "Then, you can press the space bar to confirm your selection.\n"
            "Be careful, once you have clicked on a ball, you cannot unclick it.\n\n"
            "Press the space bar to continue.",
            amotImage,
        )

        showTextAndWaitSpace(
            "Before each trial starts, a white '+' sign is going to appear briefly on the screen.\n"
            "Please fixate your eyes on it until the balls appear.\n\n"
            "Press the space bar to start with some practice trials."
        )

        # Practice trials AMOT
        for i in range(len(nRedCirclesPerConditionPractice)):
            trialNumRedCircles = nRedCirclesPerConditionPractice[i]
            trialInitialCircleTime = apmot.initialCircleTime
            trialRedCircleTime = apmot.steadyRedCircleTime if isSteady else apmot.redCircleTime
            trialCircleMovingTime1 = uniform(
                apmot.steadyMinInitialCircleTime, apmot.steadyMaxInitialCircleTime
            ) if isSteady else 0
            trialCircleMovingTime2 = 0 if isSteady else uniform(
                apmot.minCirclesMovingTime, apmot.maxCirclesMovingTime
            )
            _, correctAnswers, wrongAnswers = apmot.runCondition(
                trialNumRedCircles, trialInitialCircleTime,
                trialCircleMovingTime1, trialRedCircleTime, trialCircleMovingTime2
            )
            showTextAndWaitSpace(
                "Balls tracking:\n\n Correctly tracked: {}\n Incorrectly tracked: {} "
                "\n\n Press spacebar to continue".format(correctAnswers, wrongAnswers)
            )

        showTextAndWaitSpace(
            "Here is a piece of advice to make this task easier: \n\n"
            "We recommend that you don't follow the moving blue dots with your eyes.\n"
            "Instead, it is easier to just look toward the center of the screen, where the '+' sign is, "
            "and allow your peripheral vision to do most of the work.\n\n\n"
            "Press the space bar to continue."
        )

    if isSteady:
        showTextAndImageAndWaitSpace(
            "For this part of the experiment, blue balls are going to appear on screen.\n"
            "The blue balls are going to move around the screen for a few seconds and then suddenly turn red "
            "for a very short period of time (less than a second).\n"
            "Your job is to stay vigilant for this very short moment the balls turn red (either 2 or 4 balls).\n"
            "You will need to stay focused on the balls as they move around, in order to not miss the moment they turn red.\n"
            "Once the balls have turned red and back to blue, you can use the mouse to select the balls that turned red.\n"
            "Be careful, once you have clicked on a ball, you cannot unclick it.\n"
            "Then, you can press the space bar to confirm your selection.\n\n"
            "Press the space bar to continue.",
            pmotImage,
        )

        showTextAndWaitSpace(
            "Before each trial starts, a white '+' sign is going to appear briefly on the screen.\n"
            "Please fixate your eyes on it until the balls appear.\n\n"
            "The same '+' sign will remain in the middle of the screen during the trial. "
            "Please keep your eyes focused on it as much as you can.\n\n"
            "Press the space bar to start with some practice trials."
        )

        showTextAndWaitSpace(
            "Let's practice this task.\n Press the space bar to start the practice.\n\n "
            "Do not forget to press the space bar after you are done selecting the dots."
        )
        for i in range(len(nRedCirclesPerConditionPractice)):
            trialNumRedCircles = nRedCirclesPerConditionPractice[i]
            trialInitialCircleTime = apmot.initialCircleTime
            trialRedCircleTime = apmot.steadyRedCircleTime if isSteady else apmot.redCircleTime
            trialCircleMovingTime1 = uniform(
                apmot.steadyMinInitialCircleTime, apmot.steadyMaxInitialCircleTime
            ) if isSteady else 0
            trialCircleMovingTime2 = 0 if isSteady else uniform(
                apmot.minCirclesMovingTime, apmot.maxCirclesMovingTime
            )
            _, correctAnswers, wrongAnswers = apmot.runCondition(
                trialNumRedCircles, trialInitialCircleTime,
                trialCircleMovingTime1, trialRedCircleTime, trialCircleMovingTime2
            )
            showTextAndWaitSpace(
                "Balls tracking:\n\n Correctly tracked: {}\n Incorrectly tracked: {} "
                "\n\n Press spacebar to continue".format(correctAnswers, wrongAnswers)
            )

    showTextAndWaitSpace(
        "You are going to start the real experiment now.\n"
        "Please stay focused on the task as much as you can (it is really important for us!).\n"
        "If at any time you need to take a break, please do so and let the researcher know.\n\n\n"
        "Press Space Bar when you are ready.\n\n\n"
    )

    # -----------------------------
    # Real trials
    # -----------------------------
    for i in range(len(nRedCirclesPerCondition)):
        trialIndex = i + 1
        showTextAndWaitSpace(
            "Press Space Bar when you are ready to start a new trial."
        )

        # Brief pre-trial fixation
        fixationCrossProcedure(crossTextBox)
        core.wait(fixationCrossTime)

        trialNumRedCircles = nRedCirclesPerCondition[i]
        trialInitialCircleTime = apmot.initialCircleTime
        trialRedCircleTime = apmot.steadyRedCircleTime if isSteady else apmot.redCircleTime
        trialCircleMovingTime1 = uniform(
            apmot.steadyMinInitialCircleTime, apmot.steadyMaxInitialCircleTime
        ) if isSteady else 0
        trialCircleMovingTime2 = 0 if isSteady else uniform(
            apmot.minCirclesMovingTime, apmot.maxCirclesMovingTime
        )

        reactionTime, correctAnswers, wrongAnswers = apmot.runCondition(
            trialNumRedCircles, trialInitialCircleTime,
            trialCircleMovingTime1, trialRedCircleTime, trialCircleMovingTime2
        )

        smotRandomTime = trialCircleMovingTime1 if isSteady else None
        motRandomTime = None if isSteady else trialCircleMovingTime2
        motOrSmot = "PMOT" if isSteady else "AMOT"

        csvWriter.writerow([
            age, gender.lower(), motOrSmot, trialIndex, trialNumRedCircles,
            "{:.3f}".format(reactionTime), correctAnswers, wrongAnswers,
            int(correctAnswers == trialNumRedCircles),
            motRandomTime, smotRandomTime,
        ])
        csvFile.flush()

csvFile.close()

# Debrief
showTextAndWaitSpace(
    "Thank you for participating!\n\n\n"
    "Please let the researcher know that you are done.\n\n\n"
    "Researcher: Press the space bar to end the task."
)

win.close()
core.quit()