#!/usr/bin/env python
# AP-MOT engine, behavioral-only version (no eye-tracking / iohub)
# Compatible with PsychoPy 2026.x

from psychopy import visual, core, event
from random import uniform
from math import hypot
import time

from MathUtils import pol2cart, getRandomAngle
import MovingCircle


class APMOT:
    def __init__(self, win):
        # Window and bounds
        self.win = win
        self.w = win.size[0]
        self.h = win.size[1]
        self.r = self.w / self.h
        self.borders = (-self.h / 2, self.h / 2, -self.h / 2, self.h / 2)
        # Mouse (safe to create in __init__ for the behavioral version,
        # since there is no iohub server running in this configuration).
        self.mouse = event.Mouse(visible=False, win=self.win)
        # Circles
        self.nCircles = 10
        self.cSpeed = 0.2 * self.h
        self.cRadius = 0.02 * self.h
        self.cDirectionChangeProb = 0.01  # Applied each frame
        self.cBounceDistance = (2 * self.cRadius) * 2
        self.cDefaultColor = "darkblue"
        self.cDefaultLineWidth = 1
        self.cSelectionLineColor = "white"
        self.cSelectionLineWidth = 3
        # Times for A-MOT
        self.initialCircleTime = 1
        self.redCircleTime = 2
        self.resetCircleTime = 0.5
        self.minCirclesMovingTime = 10
        self.maxCirclesMovingTime = 15
        self.selectionTimeout = 10
        # Times for P-MOT
        self.steadyMinInitialCircleTime = 10
        self.steadyMaxInitialCircleTime = 15
        self.steadyRedCircleTime = 0.1
        self.steadyCirclesMovingTime = 0
        # Misc
        self.refreshRate = 90
        self.refreshPeriod = 1 / self.refreshRate
        # Circles
        self.circles = []
        # Fixation cross
        self.crossTextBox = visual.TextBox2(
            self.win, text="+", pos=(0, 0), color="white",
            alignment="center", autoDraw=False,
        )

    def exitIfEscPressed(self):
        if event.getKeys(keyList=["escape"]):
            core.quit()

    def initCircles(self):
        for i in range(self.nCircles):
            x, y = self.getRandomSafePosition()
            c = visual.Circle(
                self.win, radius=self.cRadius,
                lineWidth=self.cDefaultLineWidth,
                lineColor=self.cDefaultColor,
                fillColor=self.cDefaultColor,
                pos=(x, y), autoDraw=False,
            )
            xVelocity, yVelocity = pol2cart(getRandomAngle(), self.cSpeed)
            mc = MovingCircle.Circle(c, xVelocity, yVelocity)
            self.circles.append(mc)

    def resetCircles(self):
        for c in self.circles:
            c.setColor(self.cDefaultColor, self.cDefaultLineWidth)
            c.visual.pos = (100, 100)  # Off-screen placeholder
        for c in self.circles:
            c.visual.pos = self.getRandomSafePosition()

    def getRandomSafePosition(self):
        xMin, xMax, yMin, yMax = self.borders
        xMin += self.cRadius
        xMax -= self.cRadius
        yMin += self.cRadius
        yMax -= self.cRadius
        positionOk = False
        x, y = 0, 0
        while not positionOk:
            x, y = uniform(xMin, xMax), uniform(yMin, yMax)
            positionOk = True
            for c in self.circles:
                xc, yc = c.visual.pos
                distance = hypot(xc - x, yc - y)
                if distance <= (2 * self.cRadius) + self.cBounceDistance:
                    positionOk = False
                    break
        return (x, y)

    def drawFixationCross(self, draw):
        self.crossTextBox.autoDraw = draw
        self.win.flip()

    def moveCircles(self, circlesMovingTime):
        circlesMovingStartTime = time.perf_counter()
        circlesMovingEndTime = circlesMovingStartTime + circlesMovingTime
        while time.perf_counter() < circlesMovingEndTime:
            frameStartTime = time.perf_counter()
            for i in range(self.nCircles):
                ci = self.circles[i]
                if uniform(0, 1) < self.cDirectionChangeProb:
                    ci.setRandomAngle()
                ci.bounceOffBorder(self.borders)
                for j in range(i + 1, self.nCircles):
                    cj = self.circles[j]
                    ci.bounceOffOther(cj, self.cBounceDistance)
                ci.move(self.refreshPeriod)
            self.win.flip()
            frameEndTime = time.perf_counter()
            frameElapsedTime = frameEndTime - frameStartTime
            if frameElapsedTime < self.refreshPeriod:
                core.wait(self.refreshPeriod - frameElapsedTime)
            self.exitIfEscPressed()

    def runCondition(self, nRedCircles, initialCircleTime,
                     circlesMovingTime1, redCircleTime, circlesMovingTime2):
        self.resetCircles()
        self.drawFixationCross(True)
        # Hide cursor during the tracking phase
        self.win.setMouseVisible(False)
        # Show circles
        for c in self.circles:
            c.visual.autoDraw = True
        self.win.flip()
        core.wait(self.initialCircleTime)
        # Move circles
        self.moveCircles(circlesMovingTime1)
        # Change circles color (targets)
        for c in self.circles[:nRedCircles]:
            c.setColor("darkgreen", self.cDefaultLineWidth)  # maroon
        self.win.flip()
        core.wait(redCircleTime)
        # Reset circle colors
        for c in self.circles[:nRedCircles]:
            c.setColor(self.cDefaultColor, self.cDefaultLineWidth)
        self.win.flip()
        core.wait(self.resetCircleTime)
        # Move circles
        self.moveCircles(circlesMovingTime2)
        # Flush keyboard buffer
        event.getKeys()

        # ---- Selection phase ----
        # Show the cursor and re-center it so it appears in a known position
        self.win.setMouseVisible(True)
        self.mouse.setPos((0, 0))
        # Drain any clicks queued from before the selection phase
        self.mouse.clickReset()

        selection = [False] * self.nCircles
        reactionStartTime = time.perf_counter()
        selectionEndTime = reactionStartTime + self.selectionTimeout
        nSelections = 0
        spacebarPressed = False
        while not (spacebarPressed and nSelections > 0) \
                and time.perf_counter() < selectionEndTime:
            for i in range(self.nCircles):
                c = self.circles[i]
                if not selection[i] and self.mouse.isPressedIn(c.visual):
                    c.setLine(self.cSelectionLineColor, self.cSelectionLineWidth)
                    selection[i] = True
                    nSelections += 1
                    spacebarPressed = False
                    self.win.flip()
            spacebarPressed = len(event.getKeys(keyList=["space"])) > 0
            self.exitIfEscPressed()
        reactionElapsedTime = time.perf_counter() - reactionStartTime

        # Hide circles and cursor again
        for c in self.circles:
            c.visual.autoDraw = False
        self.drawFixationCross(False)
        self.win.setMouseVisible(False)

        # Results
        correctAnswers = selection[:nRedCircles].count(True)
        wrongAnswers = selection[nRedCircles:].count(True)
        return reactionElapsedTime, correctAnswers, wrongAnswers